This folder contains the board backgrounds that can be used in Scid.

To add a new background simply insert a .gif file for dark squares with suffix "_d" and a .gif image for light squares with suffix "_l".
For example:
myownboard_l.gif
myownboard_d.gif

The new background will be available at next time Scid starts.
