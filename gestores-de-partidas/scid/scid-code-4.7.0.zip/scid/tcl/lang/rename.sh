#!/bin/sh

mv italian.tcl italian.tcl.bak
mv portbr.tcl portbr.tcl.bak
mv russian.tcl russian.tcl.bak
mv swedish.tcl swedish.tcl.bak
mv czech.tcl czech.tcl.bak
mv francais.tcl francais.tcl.bak
mv nederlan.tcl nederlan.tcl.bak
mv serbian.tcl serbian.tcl.bak
mv deutsch.tcl deutsch.tcl.bak
mv hungary.tcl hungary.tcl.bak
mv norsk.tcl norsk.tcl.bak
mv polish.tcl polish.tcl.bak
mv spanish.tcl spanish.tcl.bak
mv catalan.tcl catalan.tcl.bak
mv suomi.tcl suomi.tcl.bak
mv greek.tcl greek.tcl.bak

mv italian.tcl.new italian.tcl
mv portbr.tcl.new portbr.tcl
mv russian.tcl.new russian.tcl
mv swedish.tcl.new swedish.tcl
mv czech.tcl.new czech.tcl
mv francais.tcl.new francais.tcl
mv nederlan.tcl.new nederlan.tcl
mv serbian.tcl.new serbian.tcl
mv deutsch.tcl.new deutsch.tcl
mv hungary.tcl.new hungary.tcl
mv norsk.tcl.new norsk.tcl
mv polish.tcl.new polish.tcl
mv spanish.tcl.new spanish.tcl
mv catalan.tcl.new catalan.tcl
mv suomi.tcl.new suomi.tcl
mv greek.tcl.new greek.tcl
