performance and varied books are from
http://chessbazaar.mylivepage.com

Thanks to Marc Lacrosse who gave the pointer.
Those books were at first designed for the Fruit engines.

