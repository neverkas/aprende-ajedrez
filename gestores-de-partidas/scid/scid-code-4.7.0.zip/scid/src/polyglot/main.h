
// main.h

#ifndef MAIN_H
#define MAIN_H

// includes

#include "util.h"

// functions

extern void quit ();

#endif // !defined MAIN_H

// end of main.h

